<?php
require_once __DIR__ . '/../../../backend/middleware/auth.php';
require_once __DIR__ . '/../../../backend/controllers/StudentController.php';

checkAuth(['admin']);

$studentController = new StudentController();
$postResult = $studentController->handleAddStudent();
$deleteResult = $studentController->handleDeleteStudent();

$message = '';
$messageType = 'success';
$modalErrors = [];

if ($postResult['message'] !== '') {
    if ($postResult['messageType'] === 'error') {
        $modalErrors = !empty($postResult['errors']) ? $postResult['errors'] : [$postResult['message']];
    } else {
        $message = $postResult['message'];
        $messageType = $postResult['messageType'];
    }
}

if ($deleteResult['message'] !== '') {
    $message = $deleteResult['message'];
    $messageType = $deleteResult['messageType'];
}

$batches = $studentController->getActiveBatches();
$students = $studentController->getAllStudents();
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Students Management - Coaching Management System</title>
    <link rel="stylesheet" href="admin_dashboard.css">
    <link rel="stylesheet" href="students.css">
</head>

<body>
    <!-- ১. TOP NAVBAR -->
    <header class="top_navbar">
        <div class="nav_left">
            <button id="sidebarToggle" class="toggle_btn">☰</button>
            <h2 class="system_title">COACHING MANAGEMENT SYSTEM</h2>
        </div>
        <div class="nav_right">
            <span class="nav_icon" title="Notifications">🔔</span>
            <span class="nav_icon" title="Search">🔍</span>
            <div class="admin_profile">
                <span class="profile_icon">👤</span>
                <span class="admin_name">Admin ▾</span>
            </div>
        </div>
    </header>

    <!-- ২. মূল লেআউট -->
    <div class="dashboard_container">
        <!-- SIDEBAR -->
        <aside class="sidebar" id="sidebar">
            <ul class="sidebar_menu">
                <li><a href="admin_dashboard.php">🏠 <span>Dashboard</span></a></li>
                <li class="active"><a href="students.php">🎓 <span>Students</span></a></li>
                <li><a href="teachers.php">👨‍🏫 <span>Teachers</span></a></li>
                <li><a href="batches.php">📚 <span>Batches</span></a></li>
                <li><a href="classes.php">📅 <span>Classes</span></a></li>
                <li><a href="exams.php">📝 <span>Exams</span></a></li>
                <li><a href="results.php">📊 <span>Results</span></a></li>
                <li><a href="fees.php">💰 <span>Fees</span></a></li>
                <li><a href="reports.php">📑 <span>Reports</span></a></li>
                <li><a href="admin_profile.php">⚙️ <span>Profile</span></a></li>
                <li class="logout"><a href="../logout.php">🚪 <span>Logout</span></a></li>
            </ul>
        </aside>

        <!-- MAIN CONTENT -->
        <main class="main_content">
            <!-- হেডার ও অ্যাকশন বাটন -->
            <div class="page_header">
                <div>
                    <h1>Students Management</h1>
                    <p>Manage and view all enrolled students.</p>
                </div>
                <button class="action_btn" id="openAddModal"><span>+</span> Add New Student</button>
            </div>

            <!-- সার্চ ও ফিল্টার বার -->
            <div class="table_controls">
                <input type="text" class="search_input" placeholder="🔍 Search by name, roll or phone...">
                <select class="filter_select">
                    <option value="">All Batches</option>
                    <?php foreach ($batches as $batch): ?>
                        <option value="<?= htmlspecialchars($batch['name'], ENT_QUOTES, 'UTF-8'); ?>"><?= htmlspecialchars($batch['name'], ENT_QUOTES, 'UTF-8'); ?></option>
                    <?php endforeach; ?>
                </select>
            </div>

            <!-- স্টুডেন্ট টেবিল -->
            <?php if ($message !== ''): ?>
                <div class="form_message <?= $messageType; ?>"><?= htmlspecialchars($message, ENT_QUOTES, 'UTF-8'); ?></div>
            <?php endif; ?>

            <div class="table_container">
                <table class="custom_table">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Student Name</th>
                            <th>Email</th>
                            <th>Phone</th>
                            <th>Batch</th>
                            <th>Status</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($students as $student): ?>
                            <tr>
                                <td>#<?= (int) $student['id']; ?></td>
                                <td><strong><?= htmlspecialchars($student['name'], ENT_QUOTES, 'UTF-8'); ?></strong></td>
                                <td><?= htmlspecialchars($student['email'], ENT_QUOTES, 'UTF-8'); ?></td>
                                <td><?= htmlspecialchars($student['phone'], ENT_QUOTES, 'UTF-8'); ?></td>
                                <td><span class="badge"><?= htmlspecialchars($student['batch_name'] ?? 'Not assigned', ENT_QUOTES, 'UTF-8'); ?></span></td>
                                <?php $studentStatus = strtolower($student['status'] ?? 'active'); ?>
                                <td><span class="<?= $studentStatus === 'active' ? 'status_active' : 'status_inactive'; ?>"><?= htmlspecialchars(ucfirst($studentStatus), ENT_QUOTES, 'UTF-8'); ?></span></td>
                                <td>
                                    <button class="btn_icon edit_btn" title="Edit" type="button">✏️</button>
                                    <form method="post" style="display:inline;" onsubmit="return confirm('Delete student <?= htmlspecialchars(addslashes($student['name']), ENT_QUOTES, 'UTF-8'); ?>? This will permanently remove their login, enrollments, attendance, results, and fee records.');">
                                        <input type="hidden" name="action" value="delete_student">
                                        <input type="hidden" name="student_id" value="<?= (int) $student['id']; ?>">
                                        <button class="btn_icon delete_btn" title="Delete" type="submit">🗑️</button>
                                    </form>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </main>
    </div>

    <!-- ৩. ADD STUDENT MODAL (পপ-আপ ফর্ম) -->
    <div class="modal_overlay" id="studentModal">
        <div class="modal_box">
            <div class="modal_header">
                <h3>Add New Student</h3>
                <button type="button" class="close_modal" id="closeModal">&times;</button>
            </div>
            <?php if (!empty($modalErrors)): ?>
                <div class="form_message error">
                    <?php foreach ($modalErrors as $err): ?>
                        <div style="margin-bottom: 4px;">⚠️ <?= htmlspecialchars($err, ENT_QUOTES, 'UTF-8'); ?></div>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>
            <form class="modal_form" method="post">
                <input type="hidden" name="action" value="add_student">
                <div class="form_row">
                    <div class="form_group">
                        <label>Full Name</label>
                        <input type="text" name="name" value="<?= htmlspecialchars($_POST['name'] ?? '', ENT_QUOTES, 'UTF-8'); ?>" placeholder="e.g. Rahim Ahmed" minlength="2" maxlength="100" required>
                    </div>
                    <div class="form_group">
                        <label>Email Address</label>
                        <input type="email" name="email" value="<?= htmlspecialchars($_POST['email'] ?? '', ENT_QUOTES, 'UTF-8'); ?>" placeholder="name@example.com" maxlength="150" required>
                    </div>
                </div>

                <div class="form_row">
                    <div class="form_group">
                        <label>Phone Number</label>
                        <input type="tel" name="phone" value="<?= htmlspecialchars($_POST['phone'] ?? '', ENT_QUOTES, 'UTF-8'); ?>" placeholder="e.g. 01712345678" pattern="^\+?[0-9]{10,15}$" title="10 to 15 digit phone number" required>
                    </div>
                    <div class="form_group">
                        <label>Roll</label>
                        <input type="text" name="roll" value="<?= htmlspecialchars($_POST['roll'] ?? '', ENT_QUOTES, 'UTF-8'); ?>" placeholder="e.g. 101" maxlength="30" required>
                    </div>
                </div>

                <div class="form_row">
                    <div class="form_group">
                        <label>Gender</label>
                        <select name="gender" required>
                            <option value="">Select gender</option>
                            <option value="male" <?= ($_POST['gender'] ?? '') === 'male' ? 'selected' : ''; ?>>Male</option>
                            <option value="female" <?= ($_POST['gender'] ?? '') === 'female' ? 'selected' : ''; ?>>Female</option>
                            <option value="other" <?= ($_POST['gender'] ?? '') === 'other' ? 'selected' : ''; ?>>Other</option>
                        </select>
                    </div>
                    <div class="form_group">
                        <label>Guardian Phone</label>
                        <input type="tel" name="guardian_phone" value="<?= htmlspecialchars($_POST['guardian_phone'] ?? '', ENT_QUOTES, 'UTF-8'); ?>" placeholder="e.g. 01812345678" pattern="^\+?[0-9]{10,15}$" title="10 to 15 digit phone number" required>
                    </div>
                </div>

                <div class="form_row">
                    <div class="form_group">
                        <label>Select Batch (Optional)</label>
                        <select name="batch_id">
                            <option value="0">No batch assigned yet</option>
                            <?php foreach ($batches as $batch): ?>
                                <option value="<?= (int) $batch['id']; ?>" <?= ((int)($_POST['batch_id'] ?? 0) === (int)$batch['id']) ? 'selected' : ''; ?>>
                                    <?= htmlspecialchars($batch['name'], ENT_QUOTES, 'UTF-8'); ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="form_group">
                        <label>Password</label>
                        <input type="password" name="password" placeholder="At least 8 characters" minlength="8" required>
                    </div>
                </div>

                <div class="form_group">
                    <label>Address</label>
                    <input type="text" name="address" value="<?= htmlspecialchars($_POST['address'] ?? '', ENT_QUOTES, 'UTF-8'); ?>" placeholder="Student address" maxlength="255">
                </div>

                <div class="modal_buttons">
                    <button type="button" class="btn_cancel" id="cancelModal">Cancel</button>
                    <button type="submit" class="action_btn">Save Student</button>
                </div>
            </form>
        </div>
    </div>

    <!-- ৪. JavaScript -->
    <script>
        // Sidebar Toggle
        const sidebarToggle = document.getElementById('sidebarToggle');
        const sidebar = document.getElementById('sidebar');
        sidebarToggle.addEventListener('click', function () {
            if (window.innerWidth <= 768) {
                sidebar.classList.toggle('mobile_open');
            } else {
                sidebar.classList.toggle('collapsed');
            }
        });

        document.addEventListener('click', function (e) {
            if (window.innerWidth <= 768 && sidebar.classList.contains('mobile_open')) {
                if (!sidebar.contains(e.target) && !sidebarToggle.contains(e.target)) {
                    sidebar.classList.remove('mobile_open');
                }
            }
        });

        // Modal Open / Close
        const openAddModal = document.getElementById('openAddModal');
        const closeModal = document.getElementById('closeModal');
        const cancelModal = document.getElementById('cancelModal');
        const studentModal = document.getElementById('studentModal');

        openAddModal.addEventListener('click', () => studentModal.classList.add('show'));
        closeModal.addEventListener('click', () => studentModal.classList.remove('show'));
        cancelModal.addEventListener('click', () => studentModal.classList.remove('show'));
        studentModal.addEventListener('click', (e) => {
            if (e.target === studentModal) studentModal.classList.remove('show');
        });

        <?php if (!empty($modalErrors)): ?>
        studentModal.classList.add('show');
        <?php endif; ?>

        // Search & Batch Filter
        const searchInput = document.querySelector('.search_input');
        const filterSelect = document.querySelector('.filter_select');
        function filterStudents() {
            const term = (searchInput?.value || '').toLowerCase();
            const batch = (filterSelect?.value || '').toLowerCase();
            document.querySelectorAll('.custom_table tbody tr').forEach(row => {
                const text = row.textContent.toLowerCase();
                const matchesTerm = text.includes(term);
                const matchesBatch = batch === '' || text.includes(batch);
                row.style.display = (matchesTerm && matchesBatch) ? '' : 'none';
            });
        }
        searchInput?.addEventListener('keyup', filterStudents);
        filterSelect?.addEventListener('change', filterStudents);
    </script>
</body>

</html>